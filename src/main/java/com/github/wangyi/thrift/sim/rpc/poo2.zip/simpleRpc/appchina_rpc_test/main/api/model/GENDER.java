package com.github.wangyi.thrift.simpleRpc.appchina_rpc_test.main.api.model;

public enum GENDER {
	M,W
}
