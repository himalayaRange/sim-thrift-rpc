package com.github.wangyi.thrift.simpleRpc.appchina_rpc_test.test;

import java.util.LinkedList;
import java.util.List;
import org.springframework.beans.BeansException;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.github.wangyi.thrift.simpleRpc.appchina_rpc_test.main.api.AddService;
import com.github.wangyi.thrift.simpleRpc.appchina_rpc_test.main.api.MoodService;
import com.github.wangyi.thrift.simpleRpc.appchina_rpc_test.main.api.model.GENDER;
import com.github.wangyi.thrift.simpleRpc.appchina_rpc_test.main.api.model.Mood;
/*
 * 
 * ========================================================
 * 日 期：@2016-12-16
 * 作 者：wangyi
 * 版 本：1.0.0
 * 类说明：RPC 请求
 * TODO
 * ========================================================
 * 修订日期 :   
 * 修订人 :
 * 描述:
 */
public class Client {
	
	@SuppressWarnings("resource")
	public static void main(String[] args) throws BeansException, Exception {
		final ConfigurableApplicationContext ctx = new ClassPathXmlApplicationContext("/spring-thrift-rpc-customer.xml");
		
		//testError((AddService)ctx.getBean("addService"));
		//testError((AddService) ctx.getBean("otherAddService"));
		//testMood((MoodService) ctx.getBean("moodService"));
		testPref((AddService)ctx.getBean("addService"));
	}
	
	public static void testPref(AddService addService)throws Exception{
		long start = System.currentTimeMillis();
		for(int i=0;i<10000;i++){
			System.err.println(addService.add(i)+"====");
		}
		System.out.println("times:" + (System.currentTimeMillis() - start));
	}
	
	public static void testError(AddService addService)throws Exception{
		try {
			addService.exception();
			System.err.println("no error");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static void testMood(MoodService moodService) throws Exception {
		List<Mood> moodList=new LinkedList<Mood>();
		moodList.add(new Mood());
		moodList.add(new Mood());
		moodList.add(new Mood());
		moodList.add(new Mood());
		moodList.add(new Mood());
		moodService.test();
		System.out.println(moodService.test(1));
		System.out.println(moodService.test("12"));
		System.out.println(moodService.test(1, "name"));
		System.out.println(moodService.test(new Mood()));
		System.out.println(moodService.test(moodList));
		System.out.println(moodService.test(new Mood[] { new Mood() }));
		System.out.println(moodService.test(new int[] { 1, 2, 3 }));
		System.out.println(moodService.test(0, 1));
		System.out.println(moodService.test(GENDER.W));
	}
	
}
