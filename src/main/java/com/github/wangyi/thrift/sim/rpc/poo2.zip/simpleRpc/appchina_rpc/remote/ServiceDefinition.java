package com.github.wangyi.thrift.simpleRpc.appchina_rpc.remote;
/**
 * 
 * ========================================================
 * 日 期：@2016-12-12
 * 作 者：wangyi
 * 版 本：1.0.0
 * 类说明：服务的接口和实现类
 * TODO
 * ========================================================
 * 修订日期 :   
 * 修订人 :
 * 描述:
 */
public class ServiceDefinition {

	private Class<?> interfaceClass;
	
	private Object implInstance;
	
	private String serviceName;
	
	public ServiceDefinition() {
		super();
	}

	public ServiceDefinition(Class<?> interfaceClass, Object implInstance) {
		this.interfaceClass = interfaceClass;
		this.implInstance = implInstance;
	}

	public ServiceDefinition(Class<?> interfaceClass, Object implInstance, String serviceName) {
		this.interfaceClass = interfaceClass;
		this.implInstance = implInstance;
		this.serviceName = serviceName;
	}
	
	public Class<?> getInterfaceClass() {
		return interfaceClass;
	}

	public Object getImplInstance() {
		return implInstance;
	}

	public void setInterfaceClass(Class<?> interfaceClass) {
		this.interfaceClass = interfaceClass;
	}

	public void setImplInstance(Object implInstance) {
		this.implInstance = implInstance;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	@Override
	public String toString() {
		return "[interfaceClass=" + interfaceClass + ", implInstance=" + implInstance + ", serviceName=" + serviceName + "]";
	}

}
