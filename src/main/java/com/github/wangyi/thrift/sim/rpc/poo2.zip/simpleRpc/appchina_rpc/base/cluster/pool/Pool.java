package com.github.wangyi.thrift.simpleRpc.appchina_rpc.base.cluster.pool;

import java.io.Closeable;
import java.util.NoSuchElementException;
import com.github.wangyi.thrift.simpleRpc.appchina_rpc.base.client.Client;
import com.github.wangyi.thrift.simpleRpc.appchina_rpc.base.client.ClientIOException;

/**
 * 
 * ========================================================
 * 日 期：@2016-12-8
 * 作 者：wangyi
 * 版 本：1.0.0
 * 类说明：提供获取连接池的方式
 * TODO
 * ========================================================
 * 修订日期 :   
 * 修订人 :
 * 描述:
 */
public interface Pool<P,R> extends Closeable {

	/**
	 * 获取连接
	 * @return
	 * @throws NoSuchElementException
	 * @throws ClientIOException
	 */
	public BorrowedClient<P, R> borrowClient()throws NoSuchElementException,ClientIOException;
	
	/**
	 * 将连接放回
	 * @param client
	 */
	public void returnClient(BorrowedClient<P, R> client);
	
	/**
	 *将连接销毁
	 * @param client
	 */
	public void invalidateClient(BorrowedClient<P, R> client);
	
	/**
	 * 初始化Pool
	 * @throws IllegalAccessException
	 */
	public void init()throws IllegalAccessException;
	
	/**
	 * 关闭Pool
	 */
	@Override
	public void close();
	
	
	/**
	 * 
	 * ========================================================
	 * 日 期：@2016-12-8
	 * 作 者：wangyi
	 * 版 本：1.0.0
	 * 类说明：
	 * TODO
	 * ========================================================
	 * 修订日期 :   
	 * 修订人 :
	 * 描述: 被接触的连接
	 */
	public static class BorrowedClient<P,R>{
		
		public Client<P,R> client;
		
		public int index;
		
		public BorrowedClient(){
			
		}
		
		public BorrowedClient(Client<P,R> client,int index){
			this.client=client;
			this.index=index;
		}
	}
}


