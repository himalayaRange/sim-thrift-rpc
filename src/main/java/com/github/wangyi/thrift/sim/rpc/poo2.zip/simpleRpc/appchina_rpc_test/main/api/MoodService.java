package com.github.wangyi.thrift.simpleRpc.appchina_rpc_test.main.api;

import java.util.List;
import java.util.Map;
import com.github.wangyi.thrift.simpleRpc.appchina_rpc_test.main.api.model.GENDER;
import com.github.wangyi.thrift.simpleRpc.appchina_rpc_test.main.api.model.Mood;

public interface MoodService {

	public void test();
	
	public Map<String,Mood> test(Integer value);
	
	public Integer test(String value);
	
	public String test(Integer value, String value1);
	
	public Mood test(Mood value);
	
	public List<Mood> test(List<Mood> value);
	
	public Mood[] test(Mood[] value);
	
	public int[] test(int[] value);
	
	public int test(int value1, int value2);
	
	public GENDER test(GENDER value);
}
