package com.github.wangyi.thrift.simpleRpc.appchina_rpc.base.cluster.pool;

import org.apache.commons.pool2.BasePooledObjectFactory;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;
import com.github.wangyi.thrift.simpleRpc.appchina_rpc.base.client.Client;
import com.github.wangyi.thrift.simpleRpc.appchina_rpc.base.utils.CloseUtils;

/**
 * 
 * ========================================================
 * 日 期：@2016-12-8
 * 作 者：wangyi
 * 版 本：1.0.0
 * 类说明：抽象类，服务对对象池提供对象
 * TODO
 * ========================================================
 * 修订日期 :   
 * 修订人 :
 * 描述:
 */
public abstract class ClientFactory<P,R> extends BasePooledObjectFactory<Client<P,R>>{

	public ClientFactory(){
		
	}
	/**
	 * 提供客户端，不需要open，只需创建
	 * @return
	 */
	public abstract Client<P,R> createClient();

	/**
	 * 获取对象池对象并打开
	 */
	@Override
	public PooledObject<Client<P, R>> makeObject() throws Exception {
		Client<P,R> client=createClient();
		client.open();
		return new DefaultPooledObject<Client<P,R>>(client);
	}

	/**
	 * 销毁对象池对象
	 */
	@Override
	public void destroyObject(PooledObject<Client<P, R>> p) throws Exception {
		CloseUtils.close(p.getObject());
	}

	/**
	 * 校验对象池对象是否有效
	 */
	@Override
	public boolean validateObject(PooledObject<Client<P, R>> p) {
		if(p==null)return false;
		if(p.getObject()==null){
			return false;
		}
		return p.getObject().ping();
		
	}
	
	
}
