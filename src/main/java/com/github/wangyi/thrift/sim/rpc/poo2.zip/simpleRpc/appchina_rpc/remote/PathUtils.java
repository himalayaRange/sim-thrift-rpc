package com.github.wangyi.thrift.simpleRpc.appchina_rpc.remote;

import java.lang.reflect.Method;

/**
 * 
 * ========================================================
 * 日 期：@2016-12-12
 * 作 者：wangyi
 * 版 本：1.0.0
 * 类说明：请求路径处理类
 * 		将接口的方法解析为服务地址（因为方法的参数使用了简介名，可能导致重复）
 * 		可通过{@link AService}注解设置服务地址，避免重复
 * TODO
 * ========================================================
 * 修订日期 :   
 * 修订人 :
 * 描述:
 */
public final class PathUtils {

	/**
	 * 构建服务路径
	 * @param serviceName
	 * @param proxyInterface
	 * @param method
	 * @return
	 */
	public static String buildServicePath(String serviceName,Class<?> proxyInterface,Method method){
		StringBuilder sb=new StringBuilder("/");
		if(serviceName!=null){
			sb.append(serviceName).append("/");
		}
		sb.append(proxyInterface.getName()).append("/");
		return sb.append(paseRelativePath(method)).toString();
	}

	/**
	 * 反射解析注解
	 * @param method
	 * @return
	 */
	private static Object paseRelativePath(Method method) {
		AService methodAnnotation  = method.getAnnotation(AService.class);//获取Injection服务的注解
		if(methodAnnotation ==null||"".equals(methodAnnotation.value())){
			StringBuilder sb=new StringBuilder(method.getName());
			sb.append("/");
			Class<?>[] parameterTypes = method.getParameterTypes();
			if(parameterTypes!=null&&parameterTypes.length>0){
				for(Class<?> type:parameterTypes){
					sb.append(type.getSimpleName());
					sb.append("/");
				}
			}
			sb.deleteCharAt(sb.length()-1);
			System.out.println("Service Ref:"+sb.toString());
			return sb.toString();
		}else{
			System.out.println("Service Ref:"+methodAnnotation.value());
			return methodAnnotation.value();
		}
	}
}
